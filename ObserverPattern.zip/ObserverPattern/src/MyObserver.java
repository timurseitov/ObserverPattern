import java.util.List;

public interface MyObserver {
    void update(String film);
}
